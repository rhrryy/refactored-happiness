﻿#define IDC_LIST1_POINTS    1001  // 或其他唯一数值
#define IDC_BUTTON2  1002  // 数值需未被其他ID占用
#define IDC_STATIC_DRAW 1003
 // 数值需未被其他ID占用
// cccDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "ccc.h"
#include "cccDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框
// 读取控制点数据，返回true表示成功
bool CcccDlg::ReadControlPointsFromFile(const CString& filePath, std::vector<CPointData>& points)
{
	points.clear();
	CStdioFile file;
	if (!file.Open(filePath, CFile::modeRead | CFile::typeText)) {
		return false;
	}

	CString line;
	while (file.ReadString(line)) {
		line.Trim();
		if (line.IsEmpty()) continue;

		CString name;
		double x, y;
		// 假设每行格式为：点名 x y（用空格或制表符分隔）
		int pos = 0;
		 name = line.Tokenize(_T(" \t"), pos);
		if (name.IsEmpty() || pos < 0) continue;
		CString strX = line.Tokenize(_T(" \t"), pos);
		if (strX.IsEmpty() || pos < 0) continue;
		CString strY = line.Tokenize(_T(" \t"), pos);
		if (strY.IsEmpty()) continue;



		x = _tstof(strX);
		y = _tstof(strY);

		CPointData pt;
		pt.name = name;
		pt.x = x;
		pt.y = y;
		points.push_back(pt);
	}
	file.Close();
	return true;
}

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CcccDlg 对话框



CcccDlg::CcccDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CCC_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CcccDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1_POINTS, m_listCtrl);
}

BEGIN_MESSAGE_MAP(CcccDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON2, &CcccDlg::OnBnClickedButton2)
END_MESSAGE_MAP()


// CcccDlg 消息处理程序

BOOL CcccDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
		// 设置表格风格（扩展风格）
		m_listCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

		// 添加表头
		m_listCtrl.InsertColumn(0, _T("点名"), LVCFMT_LEFT, 100);    // 列1：点名，宽度100
		m_listCtrl.InsertColumn(1, _T("X坐标"), LVCFMT_LEFT, 100);   // 列2：X坐标
		m_listCtrl.InsertColumn(2, _T("Y坐标"), LVCFMT_LEFT, 100);   // 列3：Y坐标

		return TRUE;
	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CcccDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CcccDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
			// 获取绘图设备上下文
			CPaintDC dc(this);

			// 1. 定义绘图区域和坐标范围
			CRect rect;
			GetClientRect(&rect); // 获取对话框客户区大小
			int margin = 50;      // 边距
			int drawWidth = rect.Width() - 2 * margin;
			int drawHeight = rect.Height() - 2 * margin;

			// 2. 绘制坐标轴
			dc.MoveTo(margin, rect.bottom - margin);          // X轴起点（左下）
			dc.LineTo(rect.right - margin, rect.bottom - margin); // X轴
			dc.MoveTo(margin, margin);                       // Y轴起点（左上）
			dc.LineTo(margin, rect.bottom - margin);         // Y轴

			// 3. 绘制刻度（假设坐标范围1-20）
			for (int i = 1; i <= 20; i++) {
				// X轴刻度
				int xPos = margin + (i - 1) * drawWidth / 19; // 映射到像素
				dc.MoveTo(xPos, rect.bottom - margin);
				dc.LineTo(xPos, rect.bottom - margin + 5);
				CString xLabel;
				xLabel.Format(_T("%d"), i);
				dc.TextOutW(xPos - 5, rect.bottom - margin + 10, xLabel);

				// Y轴刻度
				int yPos = rect.bottom - margin - (i - 1) * drawHeight / 19;
				dc.MoveTo(margin, yPos);
				dc.LineTo(margin - 5, yPos);
				CString yLabel;
				yLabel.Format(_T("%d"), i);
				dc.TextOutW(margin - 30, yPos - 8, yLabel);
			}

			// 4. 绘制控制点（假设m_points是存储的点数组）
			if (!m_points.empty()) {
				for (const auto& pt : m_points) {
					// 将逻辑坐标(1-20)映射到像素坐标
					int x = margin + (pt.x - 1) * drawWidth / 19;
					int y = rect.bottom - margin - (pt.y - 1) * drawHeight / 19;

					dc.Ellipse(x - 3, y - 3, x + 3, y + 3); // 画点
					dc.TextOutW(x + 5, y - 10, pt.name);    // 标注点名
				}
			}
			}
	}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CcccDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

// 填充表格数据的实现
void CcccDlg::FillListCtrl(const std::vector<CPointData>& points) {
	m_listCtrl.DeleteAllItems(); // 清空现有数据

	for (int i = 0; i < points.size(); i++) {
		const CPointData& pt = points[i];

		// 插入行（点名）
		m_listCtrl.InsertItem(i, pt.name);

		// 设置后续列的数据
		CString strX, strY;
		strX.Format(_T("%.2f"), pt.x); // 保留2位小数
		strY.Format(_T("%.2f"), pt.y);
		m_listCtrl.SetItemText(i, 1, strX); // X坐标
		m_listCtrl.SetItemText(i, 2, strY); // Y坐标
	}
}
void CcccDlg::OnBnClickedButton2()
{
	// TODO: 在此添加控件通知处理程序代码
		CFileDialog dlg(TRUE, _T("txt"), NULL, OFN_FILEMUSTEXIST, _T("文本文件|*.txt||"));
		if (dlg.DoModal() == IDOK) {
			// 1. 读取文件数据到成员变量
			m_points.clear(); // 清空旧数据
			if (!ReadControlPointsFromFile(dlg.GetPathName(), m_points)) {
				AfxMessageBox(_T("文件读取失败！"));
				return;
			}

			// 2. 更新表格显示
			FillListCtrl(m_points);

			// 3. 触发绘图（重绘对话框或指定绘图控件）
			InvalidateRect(NULL, FALSE); // 重绘整个对话框
			// 或针对绘图控件重绘：
			CWnd* pDrawArea = GetDlgItem(IDC_STATIC_DRAW);
			if (pDrawArea) pDrawArea->Invalidate(FALSE);
		}
	}

